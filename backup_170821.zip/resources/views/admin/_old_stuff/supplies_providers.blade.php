@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-info">
                <div class="panel-heading">Supplies Providers List</div>

                <div class="panel-body">
					Supplies Providers
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
