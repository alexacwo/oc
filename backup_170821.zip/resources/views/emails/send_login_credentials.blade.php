@component('mail::message'){{-- Greeting --}}
 
@endcomponent