@extends('layouts.app')

@section('content')
	<div class="header_container">
		<div class="row" style="margin:0px;">
			<h1>{{ $company->company_name }} - Site Information</h1>
		</div>
	</div>
	
	@if (count($company->locations) > 0)
		<div class="container" style="margin-top:30px; margin-bottom: 30px;">
			@if (Session::has('order_message'))
				<div class="col-md-12" style="padding-left:0px;">			
					<div class="custom_alert success">
						<span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
						{{ Session::get('order_message') }}
					</div>
				</div>
			@endif	
			<div class="col-md-6" style="padding-left:0px;">
				<div class="row" style="margin-bottom: 30px;"> 
					<h3 style="margin-top:0px;">Locations:</h3>
					<div class="frontpage_header_underline"></div>
				</div> 
				<div class="row"> 
					<div class="location_options">
						@foreach ($company->locations as $location) 
							<div class="need_button hover_button need_service_block" style="margin-left:0px; text-align: left; padding-left: 20px;">
								<a href="{{url ('/company') . '/' . $company->id . '/location/' . $location->id }}">
									<div>	
										{{$loop->index + 1}}). {{ $location->friendly_name }}
									</div>
								</a>
							</div>
						@endforeach
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<div class="row" style="margin-bottom: 30px;"> 
					<h3 style="margin-top:0px;">Search for the copier:</h3>
					<div class="frontpage_header_underline"></div>
				</div> 
				<div class="row"> 
					Enter copier model or serial number or part of it:
					<br><br>
					<div class="device_friendly_name_edit_form animate-show">
						<form method="post" action="{{url ('/company') . '/' . $company->id . '/search_for_the_device'}}">
							{{ csrf_field() }}
							<input type="text" name="copier_name" />
							<button type="submit" class="hover_button">Search</button>
						</form>
					</div>
				</div> 
			</div>
		</div>
	@endif

@endsection
