<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Role extends Model
{

    protected $fillable = [
        'name'
    ];

    /**
     * A role can have many users
     *
     * @return \Illuminate\Database\Eloquent\Relations\hasOne
     */
    public function users() {

        return $this->hasMany('App\User');
    }

}
